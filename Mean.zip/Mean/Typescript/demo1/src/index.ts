function calculateTax(amount:number,format:boolean) : string|number|null
{
    const calcAmount=amount * 1.2;
    return format ?  `$ ${calcAmount.toFixed(2)} `   :  calcAmount   ;
}



let taxNumber=calculateTax(245.5,false) ;
if(typeof taxNumber == 'number'){

    let halfAmt=taxNumber/2;
    console.log(taxNumber.toFixed(2));
}
let taxString=calculateTax(100,true)  ;
if(typeof taxString =='string'){
    console.log(taxString.charAt(0));
}

let taxValue:string|number =calculateTax(0,false)! ; //not null assertion

switch(typeof  taxValue){
    case 'number' :  let halfAmt=taxValue/2;
    console.log(taxValue.toFixed(2));
    break;
    case 'string' : 
    console.log(taxValue.charAt(0));
    break;

}

// //Definitive Assignment assertion
// let amt!:number;
// amt++;


let prices=[100,75,65];
let pdst:string[]=[];
prices.forEach(value => console.log(value*10));
pdst.push("Hat");
pdst.forEach(x=> console.log(x));
console.log("After pushing multiple elements")
pdst.push(... ["Gloves","Umbrella","Socks"]);
pdst.forEach(x=> console.log(x));



// function calculateTax(amount:number):any
// {
//     return `$ ${(amount*1.2).toFixed(2)}`;
// }

// let price =500;
// let taxAmount=calculateTax(100);
// let halfShare=taxAmount/2;
// let sal=90;

// console.log(`${price}=${calculateTax(price)}`);
// console.log(`Tax Amount : ${taxAmount}`);
// console.log(`Half Amount : ${halfShare}`);

// let newResult:any=calculateTax(200);
// let myNumber:number=newResult;
// console.log(`Number Value : ${myNumber.toFixed(2)}`);