function add(x,y){
return x+y
}
function random(){
return Math.random();
}
console.log("Addition"+add(2,2));