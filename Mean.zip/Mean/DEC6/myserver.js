const http = require('http');
const server = http.createServer((req,res) =>{
	res.end("<h1>Hello From My Node Server<h1>\n");
});
server.listen( 4242 , () =>{
console.log("Server Is Running ....");
});